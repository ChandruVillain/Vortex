import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { User } from '../user';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  detailForm: FormGroup;
  user: User;
  isUserPresent: boolean=false;
  error: any;
  count:number=0;
  constructor(private userService: UserService, private router:Router) { }

  ngOnInit() {
    this.detailForm = new FormGroup({
      id: new FormControl(null),
      empId: new FormControl(null, [Validators.required, Validators.pattern('^[0-9]*')]),
      userId: new FormControl(null, [Validators.required, Validators.pattern('^[a-z A-Z]*')]),
      email: new FormControl(null, [Validators.required, Validators.pattern('^[a-z A-Z0-9_@.]*')]),
      mobile: new FormControl(null, [Validators.required, Validators.pattern('^[0-9]*')]),
      password: new FormControl(null, [Validators.required]),
      confirmPassword: new FormControl(null, [Validators.required]),
    });
  }
  get userId() { return this.detailForm.get('userId') }
  get empId() { return this.detailForm.get('empId') }
  get email() { return this.detailForm.get('email') }
  get mobile() { return this.detailForm.get('mobile') }
  get password() { return this.detailForm.get('password') }
  get confirmPassword() { return this.detailForm.get('confirmPassword') }

  isConfirmPasswordValid() {
    if ((this.detailForm.get('password').value != null) && this.detailForm.get('confirmPassword').value != null) {
      if ((this.detailForm.get('password').value != this.detailForm.get('confirmPassword').value)) {
        return true;
      } else {
        return false;
      }
    }
  }
  clickedLogin(){
    this.router.navigate(['login']);
  }
  onSubmit() {
    this.user = this.detailForm.value;
    this.userService.getUserDetails().subscribe((a => {
      console.log(this.detailForm.value);
      for (var i = 0; i < a.length; i++) {
        var obj = a[i];
        if (obj.empId == this.detailForm.value.empId) {
          this.isUserPresent = true;
          this.count++;
          console.log(this.count);
        } 
        console.log(obj.empId);
        console.log( this.detailForm.value.empId);
        console.log(this.count)      
      }
      if(this.count==0){
        this.userService.addUser(this.user).subscribe(
              (a) => {
                console.log(this.user);
                this.count=0;
              }
              , (res) => {
                this.isUserPresent = true;
                this.count=0;
              }
            )
      } else {
        this.isUserPresent = true;
        this.count=0;

      };
      console.log(this.count)
    })
    )
    console.log(this.count)
    ;
  }

}

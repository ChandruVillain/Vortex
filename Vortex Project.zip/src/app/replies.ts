export interface Replies{
    id?:number,
    p_empId?:number,
    queryId?:number;
    replies?:string;
    dated?:Date
    // question:string;
}
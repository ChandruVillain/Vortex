import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SubmissionService } from 'src/app/service/submission.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  userName: string;
  isLoggedIn: boolean;

  constructor(private router: Router,private subService:SubmissionService,private userService:UserService) {
    this.userName=this.userService.getUserName();
  }
  forumTitle = [{
    "id":"1",
    "title":"Angular"
  },{
    "id":"2",
    "title":"Java"
  },{
    "id":"3",
    "title":"Database"
  },{
    "id":"4",
    "title":"UI"
  },{
    "id":"5",
    "title":"Ionic"
  },{
    "id":"6",
    "title":"Others"
  }];

  forumNav(x){
    this.subService.setForum(x);
    this.router.navigate(['forum']);
  }
  login(){
    this.router.navigate(['login']);
  }
  signup(){
    this.router.navigate(['register'])
  }
  ngOnInit(){
    this.isLoggedIn=this.userService.getLogin();
    console.log(this.isLoggedIn)

  }
}

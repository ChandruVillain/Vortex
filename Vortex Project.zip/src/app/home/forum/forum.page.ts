import { Component, OnInit } from '@angular/core';
import { SubmissionService } from 'src/app/service/submission.service';
import { Query } from 'src/app/query';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-forum',
  templateUrl: './forum.page.html',
  styleUrls: ['./forum.page.scss'],
})
export class ForumPage implements OnInit {
  forumHead: string;
  submissions: Query;
  forumTitle: string;
  userName: string;
  isLoggedIn: boolean;
  searchText;
  constructor(private subService:SubmissionService, private router:Router,private userService:UserService) {
    this.forumHead=this.subService.getForum();
    this.userName=this.userService.getUserName();
   }
   login(){
    this.router.navigate(['login']);
  }
  signup(){
    this.router.navigate(['register'])
  }
    posts(x){
      this.router.navigate(['submissions']);
      this.subService.setDisscussion(x);
    }
  ngOnInit() {
    this.isLoggedIn=this.userService.getLogin();

    this.forumTitle=this.forumHead.toLowerCase();
    console.log(this.forumTitle)
    this.subService.getAllPosts().subscribe((a)=>{
      
      this.submissions=a;
      for (var i = 0; i < a.length; i++) {
        var obj = a[i];
        console.log(obj.queryType);
      }
     
      // for (let i = 0; i < a.userId.length; i++)
      //   {
      //     const words = a.userId[i].split(' ');
      //     Users.push(words[0]);
      //   }
    })
  }


}

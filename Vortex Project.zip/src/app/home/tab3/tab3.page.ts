import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SubmissionService } from 'src/app/service/submission.service';
import { Query } from 'src/app/query';
import { UserService } from 'src/app/service/user.service';
import { Replies } from 'src/app/replies';
import { User } from 'src/app/user';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  queryForm: FormGroup;
  isUserPresent: boolean = false;
  error: any;
  count: number = 0;
  parts: string;

  submissions: Query={};
  userName: string;
  isLoggedIn: boolean;
  usId: number;
  newSubmissions:Query;
  useId: number;
  repSubmissions: Replies;
  user: User;
  // idd:string;
  // commentss:FormGroup
  // commentss: Comments;
  constructor(private router: Router, private submissionService: SubmissionService, private userService:UserService) {
    this.userName=this.userService.getUserName();
    this.useId=this.userService.getUserId();
   }
   ionViewWillEnter(){
    this.userName=this.userService.getUserName();
    this.isLoggedIn=this.userService.getLogin();
    this.useId=this.userService.getUserId();

  }
  posts(x){
    this.submissionService.setDisscussion(x);
    this.submissionService.setSubmission(x);
    this.router.navigate(['submissions']);
    console.log(x);
  }
  ngOnInit() {
    this.useId=this.userService.getUserId();
    // this.userService.
    this.userService.getUserDetails().subscribe((a)=>{
      this.user=a;
    });
    this.submissionService.getReplies().subscribe((b)=>{
      this.repSubmissions=b;
    })
    // this.userService.getUserDetails().subscribe((c)=>{
    //   for(var i=0;i<c.length;i++){
    //     if(c[i].q_empId==this.useId)
    //     var obj=c[i];
    //     this.newSubmissions=obj;
    //   }
    // })
    this.submissionService.getAllPosts().subscribe((a)=>{
    //   for(var i=0;i<a.length;i++){
    //     if(a[i].q_empId==this.useId)
    //     var obj=a[i];
    //     this.newSubmissions=obj;
    //   }
    this.newSubmissions=a;
    })
  
    console.log(this.newSubmissions)
    this.isLoggedIn=this.userService.getLogin();
    this.queryForm = new FormGroup({
      id: new FormControl(null),
      q_empId: new FormControl(null),
      queryType: new FormControl(null, [Validators.required]),
      question: new FormControl(null, [Validators.required]),
      ques_body: new FormControl([null], [Validators.required]),
      datePosted: new FormControl(null)
    });
    // this.submissions.comment=new FormGroup({
    //   comment: new FormControl(null, [Validators.required]),
    // })
  }
  get q_empId() { return this.queryForm.get('q_empId') }
  get queryType() { return this.queryForm.get('queryType') }
  get question() { return this.queryForm.get('question') }
  get ques_body() { return this.queryForm.get('ques_body') }
  login(){
    this.router.navigate(['login']);
  }
  signup(){
    this.router.navigate(['register'])
  }
  onSubmit(x) {
    this.submissions.q_empId=this.submissionService.getEmp();
    this.submissions.datePosted = new Date();
    this.submissions.queryType = this.queryForm.value.queryType;
    this.submissions.question = this.queryForm.value.question;
    this.submissions.ques_body=this.queryForm.value.ques_body;
    this.submissionService.addQuery(this.submissions).subscribe();
    console.log(this.submissions);
   
    // this.submissions.comment[0].body=this.queryForm.value.comments;
    // console.log(this.submissions.comment[0])
    // this.submissions.comments[0].body=this.queryForm.value.comments;
    // console.log(this.submissions.comments[0])
    // this.submissionService.addQuery(this.submissions).subscribe((a)=>{
    //   console.log(a);
    // })
    // for (var i = 0; i < this.comments[i].comments.length; i++) {
    //   this.submissions.comments.entries.=this.queryForm.value.comment;

    //     // this.submissions.comments[0].body=this.queryForm.value.comment;
    //     console.log(this.submissions.comments[i].body);
    //   }

    console.log(this.submissions);
  }
}

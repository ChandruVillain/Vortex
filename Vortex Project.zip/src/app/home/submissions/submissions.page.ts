import { Component, OnInit } from '@angular/core';
import { Query } from 'src/app/query';
import { SubmissionService } from 'src/app/service/submission.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';
import { Replies } from 'src/app/replies';
import { User } from 'src/app/user';

@Component({
  selector: 'app-submissions',
  templateUrl: './submissions.page.html',
  styleUrls: ['./submissions.page.scss'],
})
export class SubmissionsPage implements OnInit {
  // obj:any;
  submissions:Query;
  comments:Replies;
  subId: number;
  discuss: Replies;
  userName: string;
  isLoggedIn: boolean;
  discussForm: FormGroup;
  newSubmission: Query;
  usId:number;
  user:User;
  constructor(private submissionService:SubmissionService, private router:Router,private userService:UserService) {
    this.subId=this.submissionService.getDisscussion();
    this.userName=this.userService.getUserName();
    this.submissionService.getReplies().subscribe((a)=>{
      for(var i=0;i<a.length;i++){
        if(a[i].queryId==this.subId){
          var objj=a[i];
          this.usId=objj.p_empId;
        }
      }
      this.discuss=a;
      console.log(a);
    })
  }
  login(){
    this.router.navigate(['login']);
  }
  signup(){
    this.router.navigate(['register'])
  }
  ngOnInit() {
    
    
    this.isLoggedIn=this.userService.getLogin();
    this.discussForm = new FormGroup({
      id: new FormControl(null),
      body:new FormControl(null),
      dated: new FormControl(null),
      postId: new FormControl(null),
      answer: new FormControl(null),
      
    });
   this.userService.getUserDetails().subscribe((a)=>{
    //  for(var i=0;i<a.length;i++){
    //    if(a[i].id==this.usId){

    //    }
    //  }
    this.user=a;
   })
    this.submissionService.getAllPosts().subscribe((a)=>{
      // const num=this.submissionService.getSubmission();
      // this.submissions=a;
      var obj=a;
      for (var i = 0; i < a.length; i++) {
        if(a[i].id==this.subId){
          obj=a[i];
          this.newSubmission=obj;
          // this.discuss=obj.comments;
          console.log(obj)
          console.log(a[i].id)
          console.log(this.subId)
          // this.submissions=this.obj;
        }
      }
     
      this.submissions=a;
      console.log(this.submissions);
      // for (let i = 0; i < a.userId.length; i++)
      //   {
      //     const words = a.userId[i].split(' ');
      //     Users.push(words[0]);
      //   }
    })
  }
  queryForm: FormGroup;
  isUserPresent: boolean=false;
  error: any;
  count:number=0;
  get userId() { return this.queryForm.get('userId') }
  get empId() { return this.queryForm.get('empId') }
  get queryType() { return this.queryForm.get('queryType') }
  get question() { return this.queryForm.get('question') }
  get information() { return this.queryForm.get('information') }
  onSubmit(){
    // this.comments.answer=this.discussForm.value.answer;
    // console.log(this.newSubmission);
   
    // this.newSubmission.comments.push(this.comments);
    
    // this.submissionService.postDiscussion(this.newSubmission).subscribe();
  }
}

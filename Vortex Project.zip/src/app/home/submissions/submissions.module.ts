import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SubmissionsPageRoutingModule } from './submissions-routing.module';

import { SubmissionsPage } from './submissions.page';
import { RouterModule } from '@angular/router';
import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';

@NgModule({
  imports: [
    CommonModule,
    ExploreContainerComponentModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    SubmissionsPageRoutingModule,
    RouterModule.forChild([{ path: '', component: SubmissionsPage }])
  ],
  declarations: [SubmissionsPage]
})
export class SubmissionsPageModule {}

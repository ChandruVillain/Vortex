import { Component, OnInit } from '@angular/core';
import { SubmissionService } from 'src/app/service/submission.service';
import { Query } from 'src/app/query';
import { Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';
// import { AngularFirestore } from '@angular/fire/firestore';

@Pipe({
  name: 'Name'
})

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  submissions:Query;
  comments:Comment;
  userName: string;
  isLoggedIn: boolean;
  searchText;
  constructor(private submissionService:SubmissionService,private router:Router,private userService:UserService) {
    this.userName=this.userService.getUserName();
  
    this.isLoggedIn=this.userService.getLogin();

  }
  login(){
    this.router.navigate(['login']);
  }
  signup(){
    this.router.navigate(['register'])
  }
  ionViewWillEnter(){
    this.userName=this.userService.getUserName();
    this.isLoggedIn=this.userService.getLogin();

  }
  ngOnInit() {
    this.isLoggedIn=this.userService.getLogin();
    console.log(this.isLoggedIn)
    if(this.isLoggedIn!=true){
      
      this.router.navigate(['intro']);
    }
    this.submissionService.getAllPosts().subscribe((a)=>{
      
      this.submissions=a;
      for (var i = 0; i < a.length; i++) {
        // var obj = a[i];
      }
      console.log(a);
      // for (let i = 0; i < a.userId.length; i++)
      //   {
      //     const words = a.userId[i].split(' ');
      //     Users.push(words[0]);
      //   }
    })
  }
  posts(x){
    this.submissionService.setDisscussion(x);
    this.submissionService.setSubmission(x);
    this.router.navigate(['submissions']);
    console.log(x);
  }
}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../service/user.service';
import { Route, Router } from '@angular/router';
import { SubmissionService } from '../service/submission.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  inValidEntry: boolean;
  constructor(private subService: SubmissionService,private formBuilder: FormBuilder,private userService:UserService, private route:Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      empId: ['', [
        Validators.required
      ]],
      password: ['', [
        Validators.required
      ]]
    })
  }
  get empId() { return this.loginForm.get('empId'); }
  get password() { return this.loginForm.get('password'); }

  login(){
    // console.log(this.userService.getUserDetails().subscribe());
    this.userService.getUserDetails().subscribe((a=>{
      console.log(a);
      for(var i = 0; i < a.length; i++) {
        var obj = a[i];
        if (obj.empId == this.loginForm.value.empId && obj.password==this.loginForm.value.password) {
          this.userService.setUserName(obj.userId);
          this.userService.setUserId(obj.id);
            this.route.navigate(['tabs/tab1']);
            this.subService.setEmp(obj.id);
            this.userService.setLogin(true);
            console.log(this.inValidEntry)
          } else {
            this.inValidEntry=true;
            console.log(this.inValidEntry)
          }
          console.log(this.inValidEntry)
    }
    }));
    console.log(this.inValidEntry)
  }

}

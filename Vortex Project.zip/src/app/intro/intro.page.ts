import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-intro',
  templateUrl: './intro.page.html',
  styleUrls: ['./intro.page.scss'],
})
export class IntroPage implements OnInit {

  constructor(private router: Router,private userSer:UserService) { }

  ngOnInit() {
  }
  login(){
 this.router.navigate(['login']);
  }
  register(){
    this.router.navigate(['register']);
  }

}

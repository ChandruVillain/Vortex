export interface Query{
    id?:number,
    q_empId?: number;
    queryType?:string;
    question?:string;
    datePosted?:Date;
    ques_body?:string;
}
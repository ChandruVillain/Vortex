import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'daw',
    loadChildren: () => import('./intro/intro.module').then( m => m.IntroPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'recent',
    loadChildren: () => import('./home/recent/recent.module').then( m => m.RecentPageModule)
  },
  {
    path: 'forum',
    loadChildren: () => import('./home/forum/forum.module').then( m => m.ForumPageModule)
  }
  ,
  {
    path: 'home/recent',
    loadChildren: () => import('./home/recent/recent.module').then( m => m.RecentPageModule)
  },
  {
    path: 'home/forum',
    loadChildren: () => import('./home/forum/forum.module').then( m => m.ForumPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'intro',
    loadChildren: () => import('./intro/intro.module').then( m => m.IntroPageModule)
  },
  {
    path: '',
    loadChildren: () => import('./home/tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'submissions',
    loadChildren: () => import('./home/submissions/submissions.module').then(m => m.SubmissionsPageModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Query } from '../query';

@Injectable({
  providedIn: 'root'
})
export class SubmissionService {
  postNum:number;
  forum:string;
  emp:number;
  submissionUrl="http://localhost:4000/query";
  repliesUrl="http://localhost:5000/posts"
  discuss: number;
  constructor(private httpClient:HttpClient) { }
  getAllPosts(): Observable<any> {
    return this.httpClient.get(this.submissionUrl);
  }
  getReplies(): Observable<any> {
    return this.httpClient.get(this.repliesUrl);
  }
  public setSubmission(postNum: number) {
    this.postNum = postNum;
  }
  addQuery(submission:Query):Observable<any>{
    return this.httpClient.post<any>(this.submissionUrl,submission);
  }
  public getSubmission() {
    console.log(this.postNum);
    return this.postNum;
  }
  postDiscussion(submission:Query):Observable<any>{
    return this.httpClient.post<any>(this.submissionUrl,submission);
  }
  public getForum() {
    console.log(this.forum);
    return this.forum;
  }
  public setForum(forum: string) {
    this.forum = forum;
  }
  public getDisscussion() {
    console.log(this.forum);
    return this.discuss;
  }
  public setDisscussion(discuss: number) {
    this.discuss = discuss;
  }
  public getEmp() {
    console.log(this.forum);
    return this.emp;
  }
  public setEmp(emp: number) {
    this.emp = emp;
  }

  

}

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["register-register-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"ion-text-center\">Register</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"form-display\">\n  <ion-img class=\"img-prop\" src=\"https://i.pinimg.com/originals/e7/82/29/e7822933e29a98b6ad15299b35985828.png\">\n  </ion-img>\n\n  <form (ngSubmit)=\"onSubmit()\" [formGroup]=\"detailForm\" class=\"register-card\">\n    <input type=\"hidden\" formControlName=\"id\">\n    <div class=\"row\">\n      <div class=\"col-lg-12 col-md-12 col-sm-12\">\n        <div class=\"text-danger\" *ngIf=\"userPresent\">User Already Exists. {{error}}</div>\n        <ion-item color=\"dark\">\n          <ion-label position=\"floating\" for=\"empId\">Employee ID</ion-label>\n          <ion-input type=\"text\" class=\"form-control\" id=\"empId\" formControlName=\"empId\" required></ion-input>\n          <div class=\"text-danger \" *ngIf=\"empId.invalid &&(empId.touched||empId.dirty)\">\n            <div class=\"text-danger\" *ngIf=\"empId.touched && !empId.valid\"><small> Employee ID is\n              required</small></div>\n              <div class=\"text-danger\" *ngIf=\"empId.errors.pattern\"><small> Employee ID can only be numbers</small></div>\n       \n          </div>\n          \n           </ion-item>\n      </div>\n      <div class=\"col-lg-12 col-md-12 col-sm-12\">\n        <ion-item color=\"dark\">\n          <ion-label position=\"floating\" for=\"userId\">Username</ion-label>\n          <ion-input type=\"text\" class=\"form-control\" id=\"userId\" formControlName=\"userId\" required></ion-input>\n          <div class=\"text-danger \" *ngIf=\"userId.invalid &&(userId.touched||userId.dirty)\">\n            <small class=\"text-danger\" *ngIf=\"userId.errors.required\">Username is\n              required\n            </small>\n          </div>\n        </ion-item>\n      </div>\n    </div>\n\n    <div class=\"row\">\n      <div class=\"col-lg-6 col-md-12 col-sm-12\">\n        <ion-item color=\"dark\">\n          <ion-label position=\"floating\" for=\"email\">E-Mail<span class=\"text-danger\">*</span></ion-label>\n          <ion-input type=\"email\"  pattern=\".+@cognizant.com\" class=\"form-control\" formControlName=\"email\" id=\"email\" required></ion-input>\n          <div class=\"text-danger \" *ngIf=\"email.invalid &&(email.touched||email.dirty)\">\n            <small class=\"text-danger\" *ngIf=\"email.errors.required\">Email is\n              required\n            </small>\n            <small class=\"text-danger\" *ngIf=\"email.errors.pattern\">Enter a E-Mail address ending with @cognizant.com\n            </small>\n          </div>\n        </ion-item>\n      </div>\n      <div class=\"col-lg-6 col-md-12 col-sm-12\">\n        <ion-item color=\"dark\">\n          <ion-label position=\"floating\" for=\"mobile\">Mobile<span class=\"text-danger\">*</span></ion-label>\n          <ion-input type=\"text\" class=\"form-control\" formControlName=\"mobile\" id=\"mobile\" required></ion-input>\n          <div class=\"text-danger \" *ngIf=\"mobile.invalid &&(mobile.touched||mobile.dirty)\">\n            <small class=\"text-danger\" *ngIf=\"mobile.errors.required\">Mobile number is\n              required\n            </small>\n            <small class=\"text-danger\" *ngIf=\"mobile.errors.pattern\">Mobile number can only be numbers\n            </small>\n          </div>\n        </ion-item>\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-lg-6 col-md-12 col-sm-12\">\n        <ion-item color=\"dark\">\n          <ion-label position=\"floating\" for=\"password\">Password<span class=\"text-danger\">*</span></ion-label>\n          <ion-input type=\"password\" class=\"form-control\" id=\"password\" formControlName=\"password\" required></ion-input>\n          <div class=\"text-danger \" *ngIf=\"password.invalid &&(password.touched||password.dirty)\">\n            <small class=\"text-danger\" *ngIf=\"password.errors.required\">Password is\n              required\n            </small>\n          </div>\n        </ion-item>\n      </div>\n      <div class=\"col-lg-6 col-md-12 col-sm-12\">\n        <ion-item color=\"dark\">\n          <ion-label position=\"floating\" for=\"confirm-password\">Confirm Password<span class=\"text-danger\">*</span>\n          </ion-label>\n          <ion-input type=\"password\" class=\"form-control\" id=\"confirm-password\" formControlName=\"confirmPassword\"\n            required></ion-input>\n          <div class=\"text-danger \" *ngIf=\"confirmPassword.invalid &&(confirmPassword.touched||confirmPassword.dirty)\">\n            <small class=\"text-danger\" *ngIf=\"confirmPassword.errors.required\">Confirm\n              Password is required\n            </small>\n          </div>\n        </ion-item>\n      </div>\n      <small class=\"text-danger\" *ngIf=\"isConfirmPasswordValid()\">Passwords must\n        match.</small>\n    </div>\n    <div class=\"row justify-content-center align-items-center ion-text-center\" *ngIf=\"!userType\">\n      <ion-button type=\"submit\" color=\"tertiary\" [disabled]=\"!(detailForm.valid && !isConfirmPasswordValid())\">\n        Register</ion-button>\n    </div>\n  </form>\n</ion-content>");

/***/ }),

/***/ "./src/app/register/register-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/register/register-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: RegisterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function() { return RegisterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register.page */ "./src/app/register/register.page.ts");




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ "./src/app/register/register.module.ts":
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register-routing.module */ "./src/app/register/register-routing.module.ts");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "./src/app/register/register.page.ts");







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
    })
], RegisterPageModule);



/***/ }),

/***/ "./src/app/register/register.page.scss":
/*!*********************************************!*\
  !*** ./src/app/register/register.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".register-card {\n  position: absolute;\n  color: #f1f1f1;\n  width: 90%;\n  height: 400px;\n  top: 40%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXIvQzpcXFVzZXJzXFw4MDU5NzJcXERlc2t0b3BcXE15IFdvcmtcXFZvcnRleC9zcmNcXGFwcFxccmVnaXN0ZXJcXHJlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcmVnaXN0ZXIvcmVnaXN0ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0VBQ0MsVUFBQTtFQUNBLGFBQUE7RUFDQSxRQUFBO0VBQ0gsU0FBQTtFQUNBLHdDQUFBO1VBQUEsZ0NBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVyL3JlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWdpc3Rlci1jYXJke1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgY29sb3I6ICNmMWYxZjE7XHJcbiAgICAgd2lkdGg6IDkwJTtcclxuICAgICBoZWlnaHQ6IDQwMHB4O1xyXG4gICAgIHRvcDogNDAlO1xyXG4gIGxlZnQ6IDUwJTtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxufSIsIi5yZWdpc3Rlci1jYXJkIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb2xvcjogI2YxZjFmMTtcbiAgd2lkdGg6IDkwJTtcbiAgaGVpZ2h0OiA0MDBweDtcbiAgdG9wOiA0MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59Il19 */");

/***/ }),

/***/ "./src/app/register/register.page.ts":
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _service_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/user.service */ "./src/app/service/user.service.ts");




let RegisterPage = class RegisterPage {
    constructor(userService) {
        this.userService = userService;
    }
    ngOnInit() {
        this.detailForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            id: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null),
            empId: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[0-9]*')]),
            userId: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[a-z A-Z]*')]),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[a-z A-Z0-9_@.]*')]),
            mobile: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[0-9]*')]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            confirmPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        });
    }
    get userId() { return this.detailForm.get('userId'); }
    get empId() { return this.detailForm.get('empId'); }
    get email() { return this.detailForm.get('email'); }
    get mobile() { return this.detailForm.get('mobile'); }
    get password() { return this.detailForm.get('password'); }
    get confirmPassword() { return this.detailForm.get('confirmPassword'); }
    isConfirmPasswordValid() {
        if ((this.detailForm.get('password').value != null) && this.detailForm.get('confirmPassword').value != null) {
            if ((this.detailForm.get('password').value != this.detailForm.get('confirmPassword').value)) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    onSubmit() {
        this.user = this.detailForm.value;
        this.userService.addUser(this.user).subscribe((a) => {
            console.log(this.user);
        }, (res) => {
            this.isUserPresent = true;
        });
    }
};
RegisterPage.ctorParameters = () => [
    { type: _service_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] }
];
RegisterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-register',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./register.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./register.page.scss */ "./src/app/register/register.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"]])
], RegisterPage);



/***/ })

}]);
//# sourceMappingURL=register-register-module-es2015.js.map
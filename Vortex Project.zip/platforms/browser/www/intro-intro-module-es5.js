function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["intro-intro-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/intro/intro.page.html":
  /*!*****************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/intro/intro.page.html ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppIntroIntroPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>intro</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content class=\"col-sm-12 col-md-12 col-lg-12\">\n  <ion-slides pager=\"true\">\n      <ion-slide class=\"step-one\">\n        <ion-text color=\"light\" class=\"intro-text\">\n          <h1>Vortex</h1>\n          <p>Solutions Simplified!</p>\n        </ion-text>\n        <div class=\"img-prop\">\n        <ion-img src=\"https://www.elsetge.cat/myimg/f/163-1638949_artistic-minimalism-mobile-wallpaper-minimalist-1440-x-2560.jpg\">\n        </ion-img></div>\n        <ion-img class=\"abs-text logo-size\"\n          src=\"https://icons-for-free.com/iconfiles/png/512/Robot-1320568045013231116.png\"></ion-img>\n        <!-- <h3 class=\"abs-text\">Login to proceed</h3> -->\n        <ion-button class=\"intro-button\" color=\"tertiary\" [routerLink]=\"['login']\">Login<ion-icon name=\"log-in\"></ion-icon>\n        </ion-button>\n      </ion-slide>\n      <ion-slide class=\"step-two\">\n        <ion-text color=\"light\">\n          <h4 class=\"intro-text\">\n            <br>\n            Join with us in expanding this wonderful community..!!</h4>\n\n        </ion-text>\n        <ion-img class=\"img-prop\" src=\"https://image.winudf.com/v2/image1/Y29tLmZlZWR0aGVncmFwaC5taW5pbWFsaXNtd2FsbHBhcGVyX3NjcmVlbl83XzE1NjI1OTc1MDNfMDEw/screen-7.jpg?fakeurl=1&type=.jpg\">\n        </ion-img>\n        <div class=\"intro-button\">\n          <br>\n          <ion-button color=\"tertiary\" [routerLink]=\"['register']\">Register<ion-icon name=\"log-in\"></ion-icon>\n          </ion-button>\n        </div>\n      </ion-slide>\n  </ion-slides>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/intro/intro-routing.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/intro/intro-routing.module.ts ***!
    \***********************************************/

  /*! exports provided: IntroPageRoutingModule */

  /***/
  function srcAppIntroIntroRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IntroPageRoutingModule", function () {
      return IntroPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _intro_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./intro.page */
    "./src/app/intro/intro.page.ts");

    var routes = [{
      path: '',
      component: _intro_page__WEBPACK_IMPORTED_MODULE_3__["IntroPage"]
    }];

    var IntroPageRoutingModule = function IntroPageRoutingModule() {
      _classCallCheck(this, IntroPageRoutingModule);
    };

    IntroPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], IntroPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/intro/intro.module.ts":
  /*!***************************************!*\
    !*** ./src/app/intro/intro.module.ts ***!
    \***************************************/

  /*! exports provided: IntroPageModule */

  /***/
  function srcAppIntroIntroModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IntroPageModule", function () {
      return IntroPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _intro_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./intro-routing.module */
    "./src/app/intro/intro-routing.module.ts");
    /* harmony import */


    var _intro_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./intro.page */
    "./src/app/intro/intro.page.ts");

    var IntroPageModule = function IntroPageModule() {
      _classCallCheck(this, IntroPageModule);
    };

    IntroPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _intro_routing_module__WEBPACK_IMPORTED_MODULE_5__["IntroPageRoutingModule"]],
      declarations: [_intro_page__WEBPACK_IMPORTED_MODULE_6__["IntroPage"]]
    })], IntroPageModule);
    /***/
  },

  /***/
  "./src/app/intro/intro.page.scss":
  /*!***************************************!*\
    !*** ./src/app/intro/intro.page.scss ***!
    \***************************************/

  /*! exports provided: default */

  /***/
  function srcAppIntroIntroPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".img-prop {\n  height: 100%;\n  width: 100%;\n}\n\n.intro-text {\n  position: absolute;\n  top: 80px;\n  background: #272727;\n  background: rgba(0, 0, 0, 0.5);\n  color: #f1f1f1;\n  width: 90%;\n  height: 110px;\n  left: 50%;\n  border-style: solid;\n  border-color: #ffab8d;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.abs-text {\n  top: 450px;\n  position: absolute;\n}\n\n.logo-size {\n  height: 150px;\n  top: 200px;\n}\n\n.intro-button {\n  position: absolute;\n  top: 550px;\n  color: #f1f1f1;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  border-radius: 0.5em;\n}\n\n.mobile-size {\n  height: 960px;\n  width: 540px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW50cm8vQzpcXFVzZXJzXFw4MDU5NzJcXERlc2t0b3BcXE15IFdvcmtcXFZvcnRleC9zcmNcXGFwcFxcaW50cm9cXGludHJvLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaW50cm8vaW50cm8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksWUFBQTtFQUNBLFdBQUE7QUNBSjs7QURNQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxjQUFBO0VBQ0MsVUFBQTtFQUNBLGFBQUE7RUFDSCxTQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLHdDQUFBO1VBQUEsZ0NBQUE7QUNIRjs7QURNQTtFQUNJLFVBQUE7RUFDQSxrQkFBQTtBQ0hKOztBREtBO0VBQ0ksYUFBQTtFQUNBLFVBQUE7QUNGSjs7QURJQTtFQUNJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDRixTQUFBO0VBQ0Esd0NBQUE7VUFBQSxnQ0FBQTtFQUNBLG9CQUFBO0FDREY7O0FER0E7RUFDSSxhQUFBO0VBQ0EsWUFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvaW50cm8vaW50cm8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmltZy1wcm9we1xyXG4gICAgLy8gYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgLy8gb2JqZWN0LWZpdDogZmlsbDtcclxuICAgIC8vIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICBcclxuICAgIFxyXG59XHJcbi5pbnRyby10ZXh0e1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA4MHB4O1xyXG4gICAgYmFja2dyb3VuZDogcmdiKDM5LCAzOSwgMzkpOyBcclxuICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC41KTsgXHJcbiAgICBjb2xvcjogI2YxZjFmMTtcclxuICAgICB3aWR0aDogOTAlO1xyXG4gICAgIGhlaWdodDogMTEwcHg7XHJcbiAgbGVmdDogNTAlO1xyXG4gIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgYm9yZGVyLWNvbG9yOiByZ2IoMjU1LCAxNzEsIDE0MSk7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbi8vICAgICAvLyBwYWRkaW5nOiAyMHB4O1xyXG59XHJcbi5hYnMtdGV4dHtcclxuICAgIHRvcDogNDUwcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbn1cclxuLmxvZ28tc2l6ZXtcclxuICAgIGhlaWdodDogMTUwcHg7XHJcbiAgICB0b3A6IDIwMHB4O1xyXG59XHJcbi5pbnRyby1idXR0b257XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDU1MHB4O1xyXG4gICAgY29sb3I6ICNmMWYxZjE7XHJcbiAgbGVmdDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xyXG59XHJcbi5tb2JpbGUtc2l6ZXtcclxuICAgIGhlaWdodDogOTYwcHg7XHJcbiAgICB3aWR0aDogNTQwcHg7XHJcbn0iLCIuaW1nLXByb3Age1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uaW50cm8tdGV4dCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA4MHB4O1xuICBiYWNrZ3JvdW5kOiAjMjcyNzI3O1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIGNvbG9yOiAjZjFmMWYxO1xuICB3aWR0aDogOTAlO1xuICBoZWlnaHQ6IDExMHB4O1xuICBsZWZ0OiA1MCU7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1jb2xvcjogI2ZmYWI4ZDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG5cbi5hYnMtdGV4dCB7XG4gIHRvcDogNDUwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cblxuLmxvZ28tc2l6ZSB7XG4gIGhlaWdodDogMTUwcHg7XG4gIHRvcDogMjAwcHg7XG59XG5cbi5pbnRyby1idXR0b24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTUwcHg7XG4gIGNvbG9yOiAjZjFmMWYxO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcbn1cblxuLm1vYmlsZS1zaXplIHtcbiAgaGVpZ2h0OiA5NjBweDtcbiAgd2lkdGg6IDU0MHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/intro/intro.page.ts":
  /*!*************************************!*\
    !*** ./src/app/intro/intro.page.ts ***!
    \*************************************/

  /*! exports provided: IntroPage */

  /***/
  function srcAppIntroIntroPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IntroPage", function () {
      return IntroPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var IntroPage =
    /*#__PURE__*/
    function () {
      function IntroPage() {
        _classCallCheck(this, IntroPage);
      }

      _createClass(IntroPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return IntroPage;
    }();

    IntroPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-intro',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./intro.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/intro/intro.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./intro.page.scss */
      "./src/app/intro/intro.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], IntroPage);
    /***/
  }
}]);
//# sourceMappingURL=intro-intro-module-es5.js.map